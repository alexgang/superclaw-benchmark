#!/usr/bin/env python3
"""Render the Opus accuracy adjudication of the OEM-116 rerun as Markdown + CSV."""
import csv
import json
import os

BASE = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
OUTDIR = os.path.join(BASE, "results_oem116")
V = os.path.join(OUTDIR, "opus_accuracy_oem116.jsonl")
S = os.path.join(OUTDIR, "opus_accuracy_oem116.json")

FM_CN = {
    "none": "全部通过",
    "partial_rubric_miss": "部分 rubric 未命中",
    "no_deliverable_produced": "未产出交付物",
    "off_task_contamination": "产出串题（写的是别题的交付物）",
    "grader_absent": "无自动检查，待人工/LLM 判",
    "suspect_stale_artifact": "疑似判到残留旧文件",
}


def main():
    verdicts = [json.loads(l) for l in open(V, encoding="utf-8") if l.strip()]
    summary = json.load(open(S, encoding="utf-8"))

    # CSV — one row per test case
    csv_path = os.path.join(OUTDIR, "opus_accuracy_oem116.csv")
    cols = ["task_id", "name", "oem_category", "grading_type", "opus_accuracy",
            "b_auto_score", "b_checks", "duration_s", "official_timeout_s",
            "within_official_timeout", "local_call_share", "failure_mode",
            "confidence", "rule", "l1_score", "l1_note",
            "own_deliverable", "stray_deliverables"]
    with open(csv_path, "w", newline="", encoding="utf-8-sig") as f:
        w = csv.writer(f)
        w.writerow(cols)
        for v in verdicts:
            w.writerow([
                v.get(c) if not isinstance(v.get(c), list)
                else ";".join(v.get(c)) for c in cols])

    h = summary["headline"]
    L = []
    A = L.append
    A("# PinchBench OEM 116 — Opus 5 accuracy 判分")
    A("")
    A(f"- 被测臂：**{summary['arm']}**　本地 `{summary['local_model']}` / 云 `{summary['cloud_model']}`")
    A(f"- 判分方：**{summary['judge']}**")
    A(f"- 覆盖：**{summary['cases_scored']}/{summary['cases_total']}** 题已判，"
      f"**{summary['cases_pending_deliverable_body']}** 题待补交付物原文")
    A("")
    A("## 结论")
    A("")
    A("| 口径 | n | accuracy |")
    A("|---|---:|---:|")
    A(f"| **严格口径**（未产出/超时=0，全部已判题） | {summary['cases_scored']} | **{h['accuracy_strict_all_scored']:.3f}** |")
    A(f"| **质量口径**（只看真正交付了产物的题） | {h['n_delivered_and_scored']} | **{h['accuracy_of_cases_that_delivered']:.3f}** |")
    A(f"| 在本题官方 timeout 内完成 | {summary['by_official_timeout']['within_official_timeout']['n']} | {summary['by_official_timeout']['within_official_timeout']['mean']:.3f} |")
    A(f"| 超出本题官方 timeout | {summary['by_official_timeout']['over_official_timeout']['n']} | {summary['by_official_timeout']['over_official_timeout']['mean']:.3f} |")
    A("")
    A(f"交付率（116 题里写出了本题要求的交付文件）：**{h['delivery_rate_all_116']:.1%}**；"
      f"完全没产出的有 **{h['n_produced_nothing']}** 题。")
    A("")
    l1 = summary["l1_delegation"]
    A("## L1 委派（子 agent 选择）")
    A("")
    A(f"计划里 accuracy = L2 rubric + L1 delegation。L1 这一维本次数据完整，可全判：")
    A("")
    A(f"- **L1 = {l1['mean']:.3f}**（{l1['n_scored']} 题有 `expected_delegation` 约束，"
      f"另 {l1['n_unconstrained']} 题不约束）")
    A(f"- 未命中 {len(l1['misses'])} 题：")
    for m in l1["misses"]:
        A(f"  - `{m['task_id']}` — {m['note']}")
    A("")
    A("其中 5 题的共同点是**整轮 116 题里 `websearch-agent` 一次都没有被调用过**"
      "（实际只出现过 `local-file-agent` 68 次、`protected-file-agent` 1 次）。"
      "需要联网检索的题因此在 L1 上系统性失分，这是路由/工具面的问题，"
      "不是模型答题能力问题。")
    A("")
    A("## 决定性因素：路由把多少调用发给了本地模型")
    A("")
    A("| 本地调用占比 | n | accuracy |")
    A("|---|---:|---:|")
    for k in ["local<20%", "local_20_50%", "local>=50%"]:
        if k in summary["by_routing_share"]:
            d = summary["by_routing_share"][k]
            A(f"| {k} | {d['n']} | **{d['mean']:.3f}** |")
    A("")
    A("这是本轮最强的单一解释变量：一旦 auto 路由把过半调用压到本地 "
      "`qwen3.5-4b`，任务基本不产出（0.12）；以云为主时 0.74–0.82。"
      "超时题的本地调用占比中位数 0.88，未超时题只有 0.22。")
    A("")
    A("47 道「没交付出本题产物」的题里，**37 道是本地主导**（本地调用≥50%），"
      "典型形态是反复调用本地模型但一个字都没落盘。剩下 10 道里有 5 道反而是"
      "云主导（`pb_csv_finance_report` / `pb_csv_gdp_regions` / "
      "`pb_log_mapreduce_timeline` / `pb_meeting_council_votes` / "
      "`pb_meeting_gov_next_steps`），失效形态不同——是 59–68 次 chat 的**打转**"
      "而不是停摆，其中 `pb_meeting_council_votes` 甚至去写了别题的 "
      "`Dockerfile.optimized`。两类要分开归因。")
    A("")
    A("## 按类别")
    A("")
    A("| 类别 | n | accuracy |")
    A("|---|---:|---:|")
    for k, d in sorted(summary["by_category"].items(), key=lambda x: -x[1]["mean"]):
        A(f"| {k} | {d['n']} | {d['mean']:.3f} |")
    A("")
    A("## 失效模式分布")
    A("")
    A("| 模式 | 题数 |")
    A("|---|---:|")
    for k, n in sorted(summary["failure_modes"].items(), key=lambda x: -x[1]):
        A(f"| {FM_CN.get(k, k)} | {n} |")
    A("")
    A("## 逐题判分（116）")
    A("")
    A("`acc` 为 Opus 判定分；`B` 为 B 机自动检查分；`本地%` 为本地调用占比；"
      "`—` 表示待补交付物原文。")
    A("")
    A("| # | task_id | 类别 | acc | B | checks | 用时s | 官方TO | 本地% | 判定 |")
    A("|---:|---|---|---:|---:|---|---:|---:|---:|---|")
    for i, v in enumerate(sorted(verdicts, key=lambda x: (
            x["opus_accuracy"] is None, x["opus_accuracy"] or 0, x["task_id"])), 1):
        acc = "—" if v["opus_accuracy"] is None else f"{v['opus_accuracy']:.3f}"
        b = "—" if v["b_auto_score"] is None else f"{v['b_auto_score']:.2f}"
        ls = "—" if v["local_call_share"] is None else f"{v['local_call_share']:.0%}"
        flag = "" if v["within_official_timeout"] else " ⏱"
        A(f"| {i} | `{v['task_id']}` | {v['oem_category']} | **{acc}** | {b} | "
          f"{v['b_checks']} | {v['duration_s']:.0f}{flag} | {v['official_timeout_s']} | "
          f"{ls} | {FM_CN.get(v['failure_mode'], v['failure_mode'])} |")
    A("")
    A("## 待补的 11 题")
    A("")
    A("这些题 `grading_type` 是 `llm_judge`/无自动检查，且交付文件已写出，"
      "但本次只同步了文件名/大小/md5，**没有正文**，因此无法判内容正确性。"
      "补齐这些题需要把 B 上 `--save-raw` 的产物目录拉回来。")
    A("")
    for v in verdicts:
        if v["opus_accuracy"] is None:
            A(f"- `{v['task_id']}` — 已产出 {', '.join(v['own_deliverable'])}"
              f"（completeness=1.0，correctness 未知）")
    A("")
    A("## 方法与已知局限")
    A("")
    A("1. B 机的自动检查器是**逐条对 rubric** 的（已抽查 pension_risk / "
      "iris_classify / meeting_tldr，检查项与 rubric 行 1:1 对应），不是 v4d "
      "那个恒等于 1.0 的伪字段，因此在有产出的题上直接采信。")
    A("2. 未产出交付物一律判 0：每题 rubric 第一行都是「文件 X 被创建」，"
      "文件不存在则整条 rubric 链失败。")
    A("3. **23 题存在串题污染**：本题窗口内落盘的是别题的交付物。把每个落盘文件"
      "按文件名归属回它所属的题、再和运行顺序对齐，可以看到交付物滞后 +1 到 "
      "+78 个任务位（228 个落盘文件中 69 个落在本题窗口、53 个落在更靠后的题、"
      "其余为中间脚本），说明超时后 SuperClaw 会话仍在后台继续写，产物落进了"
      "后面题目的工作区。这些题按 0 计，但成因是超时/串扰而非模型答错。")
    A("4. `pb_meeting_advisory_attendees` 反向可疑：8.1s / 400 output tokens、"
      "无新文件，却通过 8/9 检查，几乎可以肯定是判到了工作区里的残留文件，"
      "已标记为 low confidence。")
    A("5. 本地模型是 **qwen3.5-4b（硬件降级档）**，非官方 Qwen3-Coder-Next；"
      "云端是 MiniMax-M3 而非 GLM-5。绝对分不可与官方 ±0.03 容差直接对比。")

    md = os.path.join(OUTDIR, "opus_accuracy_oem116.md")
    with open(md, "w", encoding="utf-8") as f:
        f.write("\n".join(L))
    print(f"-> {md}")
    print(f"-> {csv_path}")


if __name__ == "__main__":
    main()
