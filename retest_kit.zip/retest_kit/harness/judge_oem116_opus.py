#!/usr/bin/env python3
"""
Opus-side accuracy adjudication for the 116-case OEM PinchBench rerun.

Input (all synced from B on 2026-08-28):
  logs/oem116_auto_pw085.jsonl      one row per case (auto arm, pw=0.85)
  logs/oem116_resume2.log           run console log
  tasks/tasks_pinchbench_oem.jsonl  the 116 case definitions (rubric + prompt)

Per CLAUDE_PLAN_V4.md the A side (this machine) owns accuracy judging and B only
executes. B's raw deliverables were NOT part of this sync, so this pass grades on
the evidence that IS present: B's per-check rubric grades, the deliverable
manifest (name/size/md5), duration vs the official per-task timeout, and the
LOCAL/CLOUD dispatch split.

Judge protocol (see the report for the reasoning behind each rule):

  R1  gradeable + its own rubric-named deliverable landed
      -> adopt B's check score. B's checks are 1:1 with the rubric lines
         (verified by hand on pension_risk / iris_classify / meeting_tldr),
         so they are a faithful deterministic grader, not the bogus
         score=1.0/0-checks field that made v4d unusable.
  R2  no deliverable at all -> 0.0. Rubric line 1 of every case is
      "file X is created"; nothing was created, so the case fails outright.
  R3  only OTHER cases' deliverables landed -> 0.0, flagged off-task.
  R4  own deliverable landed but the case has no automated checks
      (grading_type=llm_judge) -> accuracy NULL, needs the file body.
      Completeness is recorded as 1.0; correctness is unknown.

Every case also gets `measured_within_official_timeout`, so the strict
benchmark reading and the quality-only reading can both be computed.

Outputs:
  results_oem116/opus_accuracy_oem116.jsonl   per-case verdict
  results_oem116/opus_accuracy_oem116.json    aggregates
"""
import json
import os
import re
import statistics
from collections import Counter, defaultdict

BASE = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
ROWS = os.path.join(BASE, "logs", "oem116_auto_pw085.jsonl")
TASKS = os.path.join(BASE, "tasks", "tasks_pinchbench_oem.jsonl")
OUTDIR = os.path.join(BASE, "results_oem116")

HARNESS_TIMEOUT = 240.0
TIMEOUT_EPS = 2.0  # rows land at 238-241s when the 240s harness cap fires

FILE_RE = re.compile(
    r"`([^`]+\.(?:md|json|csv|txt|py|html|yml|yaml|ics|ical|sh|xlsx))`", re.I)


def load_jsonl(path, key=None):
    out = {} if key else []
    for line in open(path, encoding="utf-8"):
        if not line.strip():
            continue
        r = json.loads(line)
        if key:
            out[r[key]] = r
        else:
            out.append(r)
    return out


def rubric_targets(task):
    """Deliverable filenames the rubric/prompt names in backticks."""
    blob = (task.get("rubric") or "") + "\n" + (task.get("prompt") or "")
    return {m.split("/")[-1].lower() for m in FILE_RE.findall(blob)}


def local_share(row):
    tot = (row.get("cloud_calls") or 0) + (row.get("local_calls") or 0)
    return None if tot == 0 else (row.get("local_calls") or 0) / tot


def l1_delegation(row, task):
    """L1 = did the parent delegate to the sub-agent(s) the case expects?

    `oem_expected_delegation` is either None (unconstrained), a bare agent
    name, or a list; a `None` member means "no delegation is also acceptable".
    """
    exp = task.get("oem_expected_delegation")
    actual = sorted({sa["agent"] for sa in (row.get("sub_agents") or [])})
    if exp is None:
        return {"l1_expected": None, "l1_actual": actual,
                "l1_score": None, "l1_note": "unconstrained"}
    exp_list = exp if isinstance(exp, list) else [exp]
    allowed = {e for e in exp_list if e}
    no_delegation_ok = any(e is None for e in exp_list)
    if actual:
        ok = bool(allowed & set(actual))
        note = "delegated as expected" if ok else \
               f"delegated to {','.join(actual)}, expected {','.join(sorted(allowed))}"
    else:
        ok = no_delegation_ok
        note = "no delegation (allowed)" if ok else \
               f"no delegation, expected {','.join(sorted(allowed))}"
    return {"l1_expected": exp_list, "l1_actual": actual,
            "l1_score": 1.0 if ok else 0.0, "l1_note": note}


def judge(row, task, prev_ids):
    """Return the Opus verdict dict for one case."""
    acc = row.get("accuracy") or {}
    files = {f["path"].split("/")[-1].lower(): f["size"]
             for f in (row.get("new_files") or [])}
    targets = rubric_targets(task)
    own = sorted(targets & set(files))
    own_nonempty = [f for f in own if files[f] > 0]
    hit_timeout = row["duration_s"] >= HARNESS_TIMEOUT - TIMEOUT_EPS
    within_official = row["duration_s"] <= task["timeout_s"]
    # deliverables that belong to some EARLIER case in run order
    strays = sorted(f for f in files if f not in targets and f in prev_ids)

    v = {
        "task_id": row["task_id"],
        "name": task["name"],
        "oem_category": task["oem_category"],
        "grading_type": task["grading_type"],
        "duration_s": row["duration_s"],
        "official_timeout_s": task["timeout_s"],
        "hit_harness_timeout": hit_timeout,
        "within_official_timeout": within_official,
        "local_call_share": local_share(row),
        "cloud_calls": row.get("cloud_calls"),
        "local_calls": row.get("local_calls"),
        "own_deliverable": own_nonempty,
        "stray_deliverables": strays,
        "b_auto_score": acc.get("score"),
        "b_checks": f"{acc.get('passed', 0)}/{acc.get('total', 0)}",
        "failed_checks": [c["check"] for c in acc.get("checks", []) if not c["passed"]],
    }
    v.update(l1_delegation(row, task))

    # R1 wins whenever B's grader actually scored rubric lines: a passing
    # "file created" check proves the artifact existed even when the rubric
    # never named it in backticks (e.g. pb_calendar's project_sync.ics).
    if acc.get("gradeable") and acc.get("passed", 0) > 0:
        suspect = not files
        v.update(opus_accuracy=acc.get("score"), rule="R1",
                 basis="rubric_auto_checks",
                 confidence="low" if suspect else "high",
                 failure_mode=("suspect_stale_artifact" if suspect else
                               "none" if acc.get("score", 0) >= 0.999 else
                               "partial_rubric_miss"),
                 note=(f"B's grader passed {acc.get('passed')}/{acc.get('total')} "
                       f"rubric checks but the harness recorded NO new file, and "
                       f"the run was only {row['duration_s']:.1f}s / "
                       f"{row['tokens_out']} output tokens — too little work to "
                       f"satisfy those checks. Almost certainly graded a stale "
                       f"artifact left in the workspace. Score retained but "
                       f"flagged; treat as unverified."
                       if suspect else
                       f"B's grader ran {acc.get('total')} checks mapped 1:1 to "
                       f"the rubric lines; adopted."))
    elif not files:
        v.update(opus_accuracy=0.0, rule="R2", basis="no_output",
                 confidence="high", failure_mode="no_deliverable_produced",
                 note="Nothing was written to the workspace; rubric line 1 "
                      "(file created) fails, so every downstream line fails.")
    elif not own and strays:
        v.update(opus_accuracy=0.0, rule="R3", basis="off_task_output",
                 confidence="high", failure_mode="off_task_contamination",
                 note=f"Produced no deliverable of its own; the files that "
                      f"landed ({', '.join(strays)}) belong to earlier cases, "
                      f"i.e. a previous session was still writing.")
    elif not own:
        v.update(opus_accuracy=0.0 if not acc.get("gradeable") else acc.get("score"),
                 rule="R2", basis="no_own_deliverable", confidence="high",
                 failure_mode="no_deliverable_produced",
                 note="Only helper/intermediate files landed; the rubric's "
                      "named deliverable was never written.")
    elif acc.get("gradeable"):
        v.update(opus_accuracy=acc.get("score"), rule="R1",
                 basis="rubric_auto_checks", confidence="high",
                 failure_mode="none" if acc.get("score", 0) >= 0.999 else "partial_rubric_miss",
                 note=f"B's grader ran {acc.get('total')} checks mapped 1:1 to "
                      f"the rubric lines; adopted.")
    else:
        v.update(opus_accuracy=None, rule="R4", basis="needs_deliverable_body",
                 confidence="n/a", failure_mode="grader_absent",
                 completeness=1.0,
                 note=f"grading_type={task['grading_type']}: no automated "
                      f"checks exist, and {', '.join(own_nonempty)} "
                      f"({sum(files[f] for f in own_nonempty)} B) was produced "
                      f"but its body was not synced. Completeness=1.0; "
                      f"correctness requires the file body.")
    return v


def main():
    rows = load_jsonl(ROWS)
    tasks = load_jsonl(TASKS, key="id")
    os.makedirs(OUTDIR, exist_ok=True)

    verdicts, seen_targets = [], set()
    for row in rows:
        task = tasks[row["task_id"]]
        verdicts.append(judge(row, task, set(seen_targets)))
        seen_targets |= rubric_targets(task)

    scored = [v for v in verdicts if v["opus_accuracy"] is not None]
    pending = [v for v in verdicts if v["opus_accuracy"] is None]
    vals = [v["opus_accuracy"] for v in scored]

    def mean(xs):
        return round(statistics.mean(xs), 4) if xs else None

    delivered = [v for v in scored if v["own_deliverable"]]
    no_out = [v for v in scored if not v["own_deliverable"]]
    by_cat, by_share = defaultdict(list), defaultdict(list)
    for v in scored:
        by_cat[v["oem_category"]].append(v["opus_accuracy"])
        ls = v["local_call_share"]
        k = ("no_calls" if ls is None else
             "local<20%" if ls < 0.2 else
             "local_20_50%" if ls < 0.5 else "local>=50%")
        by_share[k].append(v["opus_accuracy"])

    summary = {
        "suite": "PinchBench OEM 116",
        "arm": "auto (hybrid router), perf_weight=0.85",
        "local_model": "qwen3.5-4b (hardware-reduced tier)",
        "cloud_model": "MiniMax-M3",
        "judge": "Claude Opus 5 (machine A), evidence-based adjudication",
        "cases_total": len(verdicts),
        "cases_scored": len(scored),
        "cases_pending_deliverable_body": len(pending),
        "headline": {
            "accuracy_strict_all_scored": mean(vals),
            "accuracy_of_cases_that_delivered": mean([v["opus_accuracy"] for v in delivered]),
            "n_delivered_and_scored": len(delivered),
            "n_produced_nothing": len(no_out),
            # counts the 11 pending cases too — they all wrote their deliverable
            "delivery_rate_all_116": round(
                sum(1 for v in verdicts if v["own_deliverable"]) / len(verdicts), 4),
        },
        "by_official_timeout": {
            "within_official_timeout": {
                "n": sum(1 for v in scored if v["within_official_timeout"]),
                "mean": mean([v["opus_accuracy"] for v in scored if v["within_official_timeout"]]),
            },
            "over_official_timeout": {
                "n": sum(1 for v in scored if not v["within_official_timeout"]),
                "mean": mean([v["opus_accuracy"] for v in scored if not v["within_official_timeout"]]),
            },
        },
        "l1_delegation": {
            "n_scored": sum(1 for v in verdicts if v["l1_score"] is not None),
            "n_unconstrained": sum(1 for v in verdicts if v["l1_score"] is None),
            "mean": mean([v["l1_score"] for v in verdicts if v["l1_score"] is not None]),
            "misses": [{"task_id": v["task_id"], "note": v["l1_note"]}
                       for v in verdicts if v["l1_score"] == 0.0],
        },
        "by_routing_share": {k: {"n": len(v), "mean": mean(v)} for k, v in sorted(by_share.items())},
        "by_category": {k: {"n": len(v), "mean": mean(v)} for k, v in sorted(by_cat.items())},
        "failure_modes": dict(Counter(v["failure_mode"] for v in verdicts)),
        "rules_applied": dict(Counter(v["rule"] for v in verdicts)),
        "pending_cases": [v["task_id"] for v in pending],
    }

    with open(os.path.join(OUTDIR, "opus_accuracy_oem116.jsonl"), "w", encoding="utf-8") as f:
        for v in verdicts:
            f.write(json.dumps(v, ensure_ascii=False) + "\n")
    with open(os.path.join(OUTDIR, "opus_accuracy_oem116.json"), "w", encoding="utf-8") as f:
        json.dump(summary, f, ensure_ascii=False, indent=2)

    print(json.dumps(summary, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
