#!/usr/bin/env python3
"""Emit the OEM-116 retest package for machine B.

Selects every case whose accuracy is not trustworthy after the 2026-08-27 run:
  A  hit the 240 s harness cap (52) — graded on a workspace the deliverable had
     not reached yet
  B  off-task contamination (23, all inside A) — the file that landed in the
     case's window belonged to an earlier case
  C  suspect stale artifact (1) — passed checks with no file written at all

and, separately, the cases that only need their deliverable body uploaded
(they ran clean, but grading_type=llm_judge so A cannot score them blind).

Outputs into results_oem116/:
  retest_tasks.json      machine-readable work order
  retest_task_ids.txt    one id per line
  RETEST_PLAN.md         the brief B executes
"""
import json
import os

BASE = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
OUTDIR = os.path.join(BASE, "results_oem116")
V = os.path.join(OUTDIR, "opus_accuracy_oem116.jsonl")
TASKS = os.path.join(BASE, "tasks", "tasks_pinchbench_oem.jsonl")

REASON_CN = {
    "off_task_contamination": "串题污染：本题窗口内落盘的是别题的交付物",
    "no_deliverable_produced": "未产出交付物（撞 240s 上限）",
    "partial_rubric_miss": "撞 240s 上限，分数在产物未落全时算出",
    "none": "撞 240s 上限，满分但产物落盘时点存疑",
    "suspect_stale_artifact": "无新文件却通过 8/9 检查，疑似判到工作区残留",
    "grader_absent": "无自动检查且撞上限",
}


def main():
    verdicts = [json.loads(l) for l in open(V, encoding="utf-8") if l.strip()]
    tasks = [json.loads(l) for l in open(TASKS, encoding="utf-8") if l.strip()]
    order = {t["id"]: i for i, t in enumerate(tasks)}
    tmap = {t["id"]: t for t in tasks}

    retest, upload_only = [], []
    for v in verdicts:
        need = v["hit_harness_timeout"] or v["failure_mode"] in (
            "off_task_contamination", "suspect_stale_artifact")
        rec = {
            "task_id": v["task_id"],
            "index": order[v["task_id"]],
            "name": v["name"],
            "oem_category": v["oem_category"],
            "official_timeout_s": v["official_timeout_s"],
            "last_duration_s": v["duration_s"],
            "last_opus_accuracy": v["opus_accuracy"],
            "local_call_share": v["local_call_share"],
            "reason": REASON_CN.get(v["failure_mode"], v["failure_mode"]),
            "stray_deliverables": v["stray_deliverables"],
        }
        if need:
            retest.append(rec)
        elif v["opus_accuracy"] is None:
            rec["reason"] = "跑得干净但 grading_type=llm_judge，A 侧需要交付物正文才能判"
            rec["deliverable"] = v["own_deliverable"]
            upload_only.append(rec)

    retest.sort(key=lambda r: r["index"])
    upload_only.sort(key=lambda r: r["index"])

    # split by whether a longer timeout can plausibly help
    stalled = [r for r in retest if (r["local_call_share"] or 0) >= 0.5
               and r["last_opus_accuracy"] in (0.0, None)]

    work = {
        "generated_for": "SuperClaw OEM PinchBench 116 — 补测",
        "source_run": "logs/oem116_auto_pw085.jsonl (auto, pw=0.85, 2026-08-27)",
        "retest_count": len(retest),
        "upload_only_count": len(upload_only),
        "tasks_arg": ",".join(str(r["index"]) for r in retest),
        "retest": retest,
        "upload_only": upload_only,
        "note_local_stalled": [r["task_id"] for r in stalled],
    }

    os.makedirs(OUTDIR, exist_ok=True)
    with open(os.path.join(OUTDIR, "retest_tasks.json"), "w", encoding="utf-8") as f:
        json.dump(work, f, ensure_ascii=False, indent=2)
    with open(os.path.join(OUTDIR, "retest_task_ids.txt"), "w", encoding="utf-8") as f:
        f.write("\n".join(r["task_id"] for r in retest) + "\n")

    write_plan(work, retest, upload_only, stalled)

    print(f"retest={len(retest)}  upload_only={len(upload_only)}  "
          f"local-stalled={len(stalled)}")
    print(f"-> {OUTDIR}\\retest_tasks.json")
    print(f"-> {OUTDIR}\\retest_task_ids.txt")
    print(f"-> {OUTDIR}\\RETEST_PLAN.md")


def write_plan(work, retest, upload_only, stalled):
    L = []
    A = L.append
    A("# OEM PinchBench 116 — 补测要求（B 侧执行）")
    A("")
    A("来源：`logs/oem116_auto_pw085.jsonl`（auto 臂，pw=0.85，2026-08-27 跑完）。")
    A("A 侧已用 Opus 5 判完 105/116，报告见 `results_oem116/opus_accuracy_oem116.md`。")
    A("本文件列出**分数不可信、需要重跑的 53 题**，以及**只需补传产物、不必重跑的 10 题**。")
    A("")
    A("## 1. 为什么要补测")
    A("")
    A("上一轮 `--timeout 240` 统一上限，**116 题里 52 题撞上限**。撞上限后 harness "
      "直接判分并进入下一题，但 SuperClaw 会话没被终止、仍在后台继续写文件，于是：")
    A("")
    A("- 本题的交付物在判分之后才落盘 → 判 0；")
    A("- 该文件落进了**后面某一题**的工作区 → 后面那题被记成「产出了别题的东西」。")
    A("  把 228 个落盘文件按文件名归属回原题再对齐运行顺序，可见交付物滞后 +1 到 "
      "+78 个任务位，**23 题**因此被污染。")
    A("")
    A("结果是 accuracy 被劈成双峰：真正交付了产物的 55 题平均 **0.939**，"
      "没交付的 50 题几乎全 0，总分被压到 **0.509**。这个总分测的是 harness，不是模型。")
    A("")
    A("## 2. timeout 定多少（重要）")
    A("")
    A("按「产物最终落盘时刻 − 该题开始时刻」重建了各题**真正需要的时间**：")
    A("")
    A("| 上限 | 能救回的题数（在 20 道最终有产出的题里） |")
    A("|---:|---|")
    A("| 300 s | 7 / 20 |")
    A("| 480 s | 12 / 20 |")
    A("| **600 s** | **13 / 20** |")
    A("| 900 s | 15 / 20 |")
    A("| 1200 s | 17 / 20 |")
    A("")
    A("**但要先看清楚：光加时间救不回大头。** 47 道没交付的题里，"
      f"只有 15 道最终产出了东西（本地调用占比中位数 0.64）；另外 **32 道自始至终"
      "什么都没写**，它们的本地调用占比中位数是 **1.00**——纯本地跑、反复调用、"
      "零落盘。这 32 题是路由/本地模型的问题，给多久都没用。")
    A("")
    A("**建议：**")
    A("")
    A("1. **主口径**：用任务文件里自带的 per-task `timeout_s`（92 题=180s，"
      "8 题=300s，8 题=120s，6 题=240s，2 题=90s），不要再用统一 240s 覆盖。"
      "这才是能和官方基线对齐的口径。上一轮统一 240s 既短于 8 道 300s 的题、"
      "又长于 120s/90s 的题，两头不靠。")
    A("2. **诊断口径**：本次补测跑 **`--timeout 600`**。600s 是性价比拐点——"
      "覆盖 13/15 可救回的题，再往上加到 900s 只多救 2 题却多花 4 小时。"
      f"53 题 × 600s 上限，墙钟约 **8.7 h**。")
    A("3. **`--timeout` 改大之后必须同时做第 3 节的会话终止**，否则只是把污染"
      "推迟发生，问题一模一样。")
    A("")
    A("## 3. 跑之前必须先修的 3 件事")
    A("")
    A("| # | 修什么 | 为什么 |")
    A("|---|---|---|")
    A("| 1 | **超时后先终止 SuperClaw 会话再进下一题**：abort 该 session，"
      "确认进程/会话真的停了（轮询到 idle 或强杀），然后才做 workspace restore。 | "
      "这是串题污染的唯一成因。不修的话 600s 一样污染。 |")
    A("| 2 | **每题结束后校验工作区回到 pristine baseline**，发现残留就报错中止，"
      "不要静默继续。 | `pb_meeting_advisory_attendees` 只跑了 8.1s / 400 tokens、"
      "一个新文件都没写，却过了 8/9 检查——判到了上一题留下的残留文件。 |")
    A("| 3 | **`--save-raw` 必须把交付物正文落到 "
      "`results/v4_raw/<arm>/<task_id>/`**，并在 restore 删文件**之前**拷走。 | "
      "这次同步过来只有文件名/大小/md5，没有正文，A 侧 11 道 llm_judge 题判不了。 |")
    A("")
    A("## 4. 要重跑的 53 题")
    A("")
    A("`lh_automation.py` 的 `--tasks` 参数（对应 `tasks_pinchbench_oem.jsonl` 行号）：")
    A("")
    A("```")
    A(work["tasks_arg"])
    A("```")
    A("")
    A("`本地%` 是上一轮的本地调用占比。**标 ⚠ 的 38 题是本地主导且零产出**——"
      "如果这一轮它们在 600s 下**仍然**零产出，那就坐实是路由/本地模型的问题，"
      "请在回传里单独标注，不要再算进 timeout 账上。")
    A("")
    A("| # | task_id | 类别 | 上轮分 | 上轮用时 | 官方TO | 本地% | 补测原因 |")
    A("|---:|---|---|---:|---:|---:|---:|---|")
    stall = {r["task_id"] for r in stalled}
    for i, r in enumerate(retest, 1):
        acc = "—" if r["last_opus_accuracy"] is None else f"{r['last_opus_accuracy']:.2f}"
        ls = "—" if r["local_call_share"] is None else f"{r['local_call_share']:.0%}"
        mark = " ⚠" if r["task_id"] in stall else ""
        A(f"| {i} | `{r['task_id']}`{mark} | {r['oem_category']} | {acc} | "
          f"{r['last_duration_s']:.0f}s | {r['official_timeout_s']}s | {ls} | {r['reason']} |")
    A("")
    A("## 5. 只需补传产物、不必重跑的 10 题")
    A("")
    A("这些题上一轮跑得干净、也在官方 timeout 内写出了交付物，只是 "
      "`grading_type=llm_judge` 没有自动检查，A 侧需要**文件正文**才能判内容正确性。"
      "把它们的交付物原文打包回传即可。")
    A("")
    A("| task_id | 交付物 | 上轮用时 |")
    A("|---|---|---:|")
    for r in upload_only:
        A(f"| `{r['task_id']}` | {', '.join(r.get('deliverable') or [])} | "
          f"{r['last_duration_s']:.0f}s |")
    A("")
    A("## 6. 回传给 A 的东西")
    A("")
    A("1. `logs/oem_retest53_pw085.jsonl` — 53 题的新结果行（字段与上轮一致）")
    A("2. `results/v4_raw/oem_retest/<task_id>/` — **每题交付物正文**（含第 5 节那 10 题）")
    A("3. `llmrouter_manager-*.log` — 本轮路由日志")
    A("4. 一行说明：哪些题在 600s 下**依然**零产出")
    A("")
    A("## 7. 跑之前自检")
    A("")
    A("- [ ] SuperClaw 健康：`curl 127.0.0.1:18321/v1/models`，auto / local / cloud 三槽都在")
    A("- [ ] `HTTP(S)_PROXY` 已清空（B 上那个 `child-prc.sh.intel.com:913` 不可解析）")
    A("- [ ] 超时终止会话的逻辑已接上（第 3 节 #1），用 1 道必超时的题验证过："
      "下一题的 `new_files` 里不再出现上一题的交付物")
    A("- [ ] `--save-raw` 落盘路径可写，且在 restore 之前拷贝")
    A("- [ ] 工作区 pristine baseline = 15 files，跑前跑后都校验")
    A("")
    A("## 8. 已知口径")
    A("")
    A("本地是 **qwen3.5-4b（硬件降级档）**，非官方 Qwen3-Coder-Next；云是 "
      "**MiniMax-M3** 非 GLM-5。绝对分不与官方 ±0.03 容差直接对比，只做臂间对比。")

    with open(os.path.join(OUTDIR, "RETEST_PLAN.md"), "w", encoding="utf-8") as f:
        f.write("\n".join(L))


if __name__ == "__main__":
    main()
