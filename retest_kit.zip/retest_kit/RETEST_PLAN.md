# OEM PinchBench 116 — 补测要求（B 侧执行）

来源：`logs/oem116_auto_pw085.jsonl`（auto 臂，pw=0.85，2026-08-27 跑完）。
A 侧已用 Opus 5 判完 105/116，报告见 `results_oem116/opus_accuracy_oem116.md`。
本文件列出**分数不可信、需要重跑的 53 题**，以及**只需补传产物、不必重跑的 10 题**。

## 1. 为什么要补测

上一轮 `--timeout 240` 统一上限，**116 题里 52 题撞上限**。撞上限后 harness 直接判分并进入下一题，但 SuperClaw 会话没被终止、仍在后台继续写文件，于是：

- 本题的交付物在判分之后才落盘 → 判 0；
- 该文件落进了**后面某一题**的工作区 → 后面那题被记成「产出了别题的东西」。
  把 228 个落盘文件按文件名归属回原题再对齐运行顺序，可见交付物滞后 +1 到 +78 个任务位，**23 题**因此被污染。

结果是 accuracy 被劈成双峰：真正交付了产物的 55 题平均 **0.939**，没交付的 50 题几乎全 0，总分被压到 **0.509**。这个总分测的是 harness，不是模型。

## 2. timeout 定多少（重要）

按「产物最终落盘时刻 − 该题开始时刻」重建了各题**真正需要的时间**：

| 上限 | 能救回的题数（在 20 道最终有产出的题里） |
|---:|---|
| 300 s | 7 / 20 |
| 480 s | 12 / 20 |
| **600 s** | **13 / 20** |
| 900 s | 15 / 20 |
| 1200 s | 17 / 20 |

**但要先看清楚：光加时间救不回大头。** 47 道没交付的题里，只有 15 道最终产出了东西（本地调用占比中位数 0.64）；另外 **32 道自始至终什么都没写**，它们的本地调用占比中位数是 **1.00**——纯本地跑、反复调用、零落盘。这 32 题是路由/本地模型的问题，给多久都没用。

**建议：**

1. **主口径**：用任务文件里自带的 per-task `timeout_s`（92 题=180s，8 题=300s，8 题=120s，6 题=240s，2 题=90s），不要再用统一 240s 覆盖。这才是能和官方基线对齐的口径。上一轮统一 240s 既短于 8 道 300s 的题、又长于 120s/90s 的题，两头不靠。
2. **诊断口径**：本次补测跑 **`--timeout 600`**。600s 是性价比拐点——覆盖 13/15 可救回的题，再往上加到 900s 只多救 2 题却多花 4 小时。53 题 × 600s 上限，墙钟约 **8.7 h**。
3. **`--timeout` 改大之后必须同时做第 3 节的会话终止**，否则只是把污染推迟发生，问题一模一样。

## 3. 跑之前必须先修的 3 件事

| # | 修什么 | 为什么 |
|---|---|---|
| 1 | **超时后先终止 SuperClaw 会话再进下一题**：abort 该 session，确认进程/会话真的停了（轮询到 idle 或强杀），然后才做 workspace restore。 | 这是串题污染的唯一成因。不修的话 600s 一样污染。 |
| 2 | **每题结束后校验工作区回到 pristine baseline**，发现残留就报错中止，不要静默继续。 | `pb_meeting_advisory_attendees` 只跑了 8.1s / 400 tokens、一个新文件都没写，却过了 8/9 检查——判到了上一题留下的残留文件。 |
| 3 | **`--save-raw` 必须把交付物正文落到 `results/v4_raw/<arm>/<task_id>/`**，并在 restore 删文件**之前**拷走。 | 这次同步过来只有文件名/大小/md5，没有正文，A 侧 11 道 llm_judge 题判不了。 |

## 4. 要重跑的 53 题

`lh_automation.py` 的 `--tasks` 参数（对应 `tasks_pinchbench_oem.jsonl` 行号）：

```
9,11,14,15,17,20,25,26,30,31,32,33,35,38,39,44,46,47,48,49,50,51,52,60,61,62,63,65,66,67,68,69,71,72,74,75,77,81,82,83,84,88,90,92,96,101,104,106,109,111,112,113,115
```

`本地%` 是上一轮的本地调用占比。**标 ⚠ 的 38 题是本地主导且零产出**——如果这一轮它们在 600s 下**仍然**零产出，那就坐实是路由/本地模型的问题，请在回传里单独标注，不要再算进 timeout 账上。

| # | task_id | 类别 | 上轮分 | 上轮用时 | 官方TO | 本地% | 补测原因 |
|---:|---|---|---:|---:|---:|---:|---|
| 1 | `pb_csv_cities_growth` | csv_analysis | 1.00 | 239s | 180s | 5% | 撞 240s 上限，满分但产物落盘时点存疑 |
| 2 | `pb_csv_finance_report` | csv_analysis | 0.00 | 240s | 180s | 0% | 未产出交付物（撞 240s 上限） |
| 3 | `pb_csv_gdp_regions` | csv_analysis | 0.00 | 242s | 180s | 0% | 未产出交付物（撞 240s 上限） |
| 4 | `pb_csv_iris_classify` | csv_analysis | 0.62 | 241s | 180s | 75% | 撞 240s 上限，分数在产物未落全时算出 |
| 5 | `pb_csv_iris_summary` ⚠ | csv_analysis | 0.00 | 241s | 180s | 100% | 串题污染：本题窗口内落盘的是别题的交付物 |
| 6 | `pb_csv_life_exp_ranking` ⚠ | csv_analysis | 0.00 | 241s | 180s | 75% | 串题污染：本题窗口内落盘的是别题的交付物 |
| 7 | `pb_csv_stations_coverage` | csv_analysis | 1.00 | 241s | 180s | 15% | 撞 240s 上限，满分但产物落盘时点存疑 |
| 8 | `pb_csv_stations_filter` ⚠ | csv_analysis | 0.00 | 241s | 180s | 88% | 串题污染：本题窗口内落盘的是别题的交付物 |
| 9 | `pb_csv_temp_anomalies` ⚠ | csv_analysis | 0.00 | 241s | 180s | 100% | 串题污染：本题窗口内落盘的是别题的交付物 |
| 10 | `pb_csv_temp_decades` ⚠ | csv_analysis | 0.00 | 241s | 180s | 100% | 串题污染：本题窗口内落盘的是别题的交付物 |
| 11 | `pb_csv_temp_trend` ⚠ | csv_analysis | 0.00 | 241s | 180s | 100% | 未产出交付物（撞 240s 上限） |
| 12 | `pb_cve_security_triage` ⚠ | analysis | 0.00 | 240s | 300s | 100% | 未产出交付物（撞 240s 上限） |
| 13 | `pb_dockerfile_optimization` ⚠ | coding | 0.00 | 241s | 120s | 64% | 未产出交付物（撞 240s 上限） |
| 14 | `pb_email` ⚠ | writing | — | 241s | 180s | 100% | 无自动检查且撞上限 |
| 15 | `pb_email_reply_drafting` ⚠ | writing | 0.00 | 241s | 240s | 100% | 未产出交付物（撞 240s 上限） |
| 16 | `pb_financial_ratio_calculation` ⚠ | analysis | 0.00 | 241s | 240s | 100% | 未产出交付物（撞 240s 上限） |
| 17 | `pb_log_apache_client_issues` ⚠ | log_analysis | 0.00 | 241s | 180s | 100% | 串题污染：本题窗口内落盘的是别题的交付物 |
| 18 | `pb_log_apache_critical` ⚠ | log_analysis | 0.00 | 241s | 180s | 69% | 串题污染：本题窗口内落盘的是别题的交付物 |
| 19 | `pb_log_apache_error_summary` ⚠ | log_analysis | 0.00 | 241s | 180s | 59% | 串题污染：本题窗口内落盘的是别题的交付物 |
| 20 | `pb_log_apache_timeline` ⚠ | log_analysis | 0.00 | 241s | 180s | 64% | 串题污染：本题窗口内落盘的是别题的交付物 |
| 21 | `pb_log_apache_top_errors` ⚠ | log_analysis | 0.00 | 241s | 180s | 85% | 串题污染：本题窗口内落盘的是别题的交付物 |
| 22 | `pb_log_hdfs_block_ops` | log_analysis | 1.00 | 240s | 180s | 20% | 撞 240s 上限，满分但产物落盘时点存疑 |
| 23 | `pb_log_hdfs_connections` | log_analysis | 0.00 | 241s | 180s | 35% | 串题污染：本题窗口内落盘的是别题的交付物 |
| 24 | `pb_log_mapreduce_timeline` | log_analysis | 0.00 | 241s | 180s | 9% | 未产出交付物（撞 240s 上限） |
| 25 | `pb_log_nginx_errors` | log_analysis | 0.00 | 241s | 180s | 24% | 串题污染：本题窗口内落盘的是别题的交付物 |
| 26 | `pb_log_nginx_slow_requests` ⚠ | log_analysis | 0.00 | 241s | 180s | 50% | 串题污染：本题窗口内落盘的是别题的交付物 |
| 27 | `pb_log_nginx_status_codes` ⚠ | log_analysis | 0.00 | 241s | 180s | 100% | 串题污染：本题窗口内落盘的是别题的交付物 |
| 28 | `pb_log_nginx_user_agents` ⚠ | log_analysis | 0.00 | 241s | 180s | 100% | 串题污染：本题窗口内落盘的是别题的交付物 |
| 29 | `pb_log_ssh_brute_force` ⚠ | log_analysis | 0.00 | 241s | 180s | 100% | 串题污染：本题窗口内落盘的是别题的交付物 |
| 30 | `pb_log_ssh_failed_logins` ⚠ | log_analysis | 0.00 | 241s | 180s | 100% | 未产出交付物（撞 240s 上限） |
| 31 | `pb_log_ssh_successful` ⚠ | log_analysis | 0.00 | 241s | 180s | 100% | 未产出交付物（撞 240s 上限） |
| 32 | `pb_log_ssh_unusual_times` ⚠ | log_analysis | 0.00 | 241s | 180s | 100% | 未产出交付物（撞 240s 上限） |
| 33 | `pb_log_syslog_anomalies` ⚠ | log_analysis | 0.00 | 241s | 180s | 100% | 未产出交付物（撞 240s 上限） |
| 34 | `pb_log_syslog_auth_failures` ⚠ | log_analysis | 0.00 | 241s | 180s | 71% | 串题污染：本题窗口内落盘的是别题的交付物 |
| 35 | `pb_log_syslog_cron` ⚠ | log_analysis | 0.00 | 241s | 180s | 100% | 串题污染：本题窗口内落盘的是别题的交付物 |
| 36 | `pb_log_syslog_services` ⚠ | log_analysis | 0.00 | 241s | 180s | 100% | 未产出交付物（撞 240s 上限） |
| 37 | `pb_meeting_advisory_attendees` | meeting_analysis | 0.89 | 8s | 180s | 0% | 无新文件却通过 8/9 检查，疑似判到工作区残留 |
| 38 | `pb_meeting_blog_post` ⚠ | meeting_analysis | 0.00 | 241s | 180s | 100% | 未产出交付物（撞 240s 上限） |
| 39 | `pb_meeting_council_budget` | meeting_analysis | 0.00 | 241s | 180s | 23% | 未产出交付物（撞 240s 上限） |
| 40 | `pb_meeting_council_contact_info` | meeting_analysis | 0.00 | 241s | 180s | 29% | 串题污染：本题窗口内落盘的是别题的交付物 |
| 41 | `pb_meeting_council_neighborhood` | meeting_analysis | 0.00 | 241s | 180s | 28% | 未产出交付物（撞 240s 上限） |
| 42 | `pb_meeting_executive_summary` ⚠ | meeting_analysis | 0.00 | 241s | 180s | 75% | 串题污染：本题窗口内落盘的是别题的交付物 |
| 43 | `pb_meeting_gov_controversy` | meeting_analysis | 0.11 | 241s | 180s | 54% | 撞 240s 上限，分数在产物未落全时算出 |
| 44 | `pb_meeting_gov_next_steps` | meeting_analysis | 0.00 | 240s | 180s | 16% | 未产出交付物（撞 240s 上限） |
| 45 | `pb_meeting_searchable_index` ⚠ | meeting_analysis | 0.00 | 241s | 180s | 56% | 串题污染：本题窗口内落盘的是别题的交付物 |
| 46 | `pb_meeting_tech_messaging` ⚠ | meeting_analysis | 0.00 | 241s | 180s | 100% | 未产出交付物（撞 240s 上限） |
| 47 | `pb_memory` ⚠ | memory | 0.00 | 241s | 120s | 63% | 串题污染：本题窗口内落盘的是别题的交付物 |
| 48 | `pb_pdf_to_calendar` ⚠ | productivity | 0.00 | 241s | 180s | 100% | 未产出交付物（撞 240s 上限） |
| 49 | `pb_shell_command_generator` ⚠ | coding | 0.00 | 241s | 90s | 80% | 未产出交付物（撞 240s 上限） |
| 50 | `pb_stock` ⚠ | research | 0.00 | 241s | 180s | 100% | 串题污染：本题窗口内落盘的是别题的交付物 |
| 51 | `pb_subway_navigation` ⚠ | productivity | 0.00 | 241s | 180s | 91% | 未产出交付物（撞 240s 上限） |
| 52 | `pb_summary` ⚠ | analysis | 0.00 | 241s | 240s | 100% | 未产出交付物（撞 240s 上限） |
| 53 | `pb_todo_list_cleanup` ⚠ | productivity | 0.00 | 241s | 120s | 100% | 未产出交付物（撞 240s 上限） |

## 5. 只需补传产物、不必重跑的 10 题

这些题上一轮跑得干净、也在官方 timeout 内写出了交付物，只是 `grading_type=llm_judge` 没有自动检查，A 侧需要**文件正文**才能判内容正确性。把它们的交付物原文打包回传即可。

| task_id | 交付物 | 上轮用时 |
|---|---|---:|
| `pb_access_log_anomaly` | anomaly_report.json | 75s |
| `pb_blog` | blog_post.md | 71s |
| `pb_commit_message_writer` | commit_message.txt | 24s |
| `pb_competitive_research` | competitive_analysis.md | 180s |
| `pb_contract_analysis` | contract_analysis.md | 65s |
| `pb_daily_summary` | daily_briefing.md | 89s |
| `pb_eli5_pdf_summary` | eli5_summary.txt | 99s |
| `pb_events` | events.md | 30s |
| `pb_pricing_research` | pricing_comparison.md | 109s |
| `pb_readme_generation` | readme.md | 41s |

## 6. 回传给 A 的东西

1. `logs/oem_retest53_pw085.jsonl` — 53 题的新结果行（字段与上轮一致）
2. `results/v4_raw/oem_retest/<task_id>/` — **每题交付物正文**（含第 5 节那 10 题）
3. `llmrouter_manager-*.log` — 本轮路由日志
4. 一行说明：哪些题在 600s 下**依然**零产出

## 7. 跑之前自检

- [ ] SuperClaw 健康：`curl 127.0.0.1:18321/v1/models`，auto / local / cloud 三槽都在
- [ ] `HTTP(S)_PROXY` 已清空（B 上那个 `child-prc.sh.intel.com:913` 不可解析）
- [ ] 超时终止会话的逻辑已接上（第 3 节 #1），用 1 道必超时的题验证过：下一题的 `new_files` 里不再出现上一题的交付物
- [ ] `--save-raw` 落盘路径可写，且在 restore 之前拷贝
- [ ] 工作区 pristine baseline = 15 files，跑前跑后都校验

## 8. 已知口径

本地是 **qwen3.5-4b（硬件降级档）**，非官方 Qwen3-Coder-Next；云是 **MiniMax-M3** 非 GLM-5。绝对分不与官方 ±0.03 容差直接对比，只做臂间对比。