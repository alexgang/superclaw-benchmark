# PinchBench OEM 116 — Opus 5 accuracy 判分

- 被测臂：**auto (hybrid router), perf_weight=0.85**　本地 `qwen3.5-4b (hardware-reduced tier)` / 云 `MiniMax-M3`
- 判分方：**Claude Opus 5 (machine A), evidence-based adjudication**
- 覆盖：**105/116** 题已判，**11** 题待补交付物原文

## 结论

| 口径 | n | accuracy |
|---|---:|---:|
| **严格口径**（未产出/超时=0，全部已判题） | 105 | **0.509** |
| **质量口径**（只看真正交付了产物的题） | 55 | **0.939** |
| 在本题官方 timeout 内完成 | 51 | 0.917 |
| 超出本题官方 timeout | 54 | 0.125 |

交付率（116 题里写出了本题要求的交付文件）：**56.9%**；完全没产出的有 **50** 题。

## L1 委派（子 agent 选择）

计划里 accuracy = L2 rubric + L1 delegation。L1 这一维本次数据完整，可全判：

- **L1 = 0.941**（102 题有 `expected_delegation` 约束，另 14 题不约束）
- 未命中 6 题：
  - `pb_competitive_research` — no delegation, expected websearch-agent
  - `pb_events` — no delegation, expected websearch-agent
  - `pb_executive_lookup` — no delegation, expected websearch-agent
  - `pb_meeting_council_contact_info` — delegated to protected-file-agent, expected local-file-agent
  - `pb_pricing_research` — no delegation, expected websearch-agent
  - `pb_stock` — no delegation, expected websearch-agent

其中 5 题的共同点是**整轮 116 题里 `websearch-agent` 一次都没有被调用过**（实际只出现过 `local-file-agent` 68 次、`protected-file-agent` 1 次）。需要联网检索的题因此在 L1 上系统性失分，这是路由/工具面的问题，不是模型答题能力问题。

## 决定性因素：路由把多少调用发给了本地模型

| 本地调用占比 | n | accuracy |
|---|---:|---:|
| local<20% | 27 | **0.744** |
| local_20_50% | 34 | **0.824** |
| local>=50% | 44 | **0.122** |

这是本轮最强的单一解释变量：一旦 auto 路由把过半调用压到本地 `qwen3.5-4b`，任务基本不产出（0.12）；以云为主时 0.74–0.82。超时题的本地调用占比中位数 0.88，未超时题只有 0.22。

47 道「没交付出本题产物」的题里，**37 道是本地主导**（本地调用≥50%），典型形态是反复调用本地模型但一个字都没落盘。剩下 10 道里有 5 道反而是云主导（`pb_csv_finance_report` / `pb_csv_gdp_regions` / `pb_log_mapreduce_timeline` / `pb_meeting_council_votes` / `pb_meeting_gov_next_steps`），失效形态不同——是 59–68 次 chat 的**打转**而不是停摆，其中 `pb_meeting_council_votes` 甚至去写了别题的 `Dockerfile.optimized`。两类要分开归因。

## 按类别

| 类别 | n | accuracy |
|---|---:|---:|
| csv_analysis | 26 | 0.624 |
| meeting_analysis | 28 | 0.614 |
| coding | 5 | 0.583 |
| analysis | 6 | 0.500 |
| research | 2 | 0.500 |
| productivity | 6 | 0.425 |
| log_analysis | 30 | 0.353 |
| memory | 1 | 0.000 |
| writing | 1 | 0.000 |

## 失效模式分布

| 模式 | 题数 |
|---|---:|
| 全部通过 | 35 |
| 未产出交付物 | 24 |
| 产出串题（写的是别题的交付物） | 23 |
| 部分 rubric 未命中 | 22 |
| 无自动检查，待人工/LLM 判 | 11 |
| 疑似判到残留旧文件 | 1 |

## 逐题判分（116）

`acc` 为 Opus 判定分；`B` 为 B 机自动检查分；`本地%` 为本地调用占比；`—` 表示待补交付物原文。

| # | task_id | 类别 | acc | B | checks | 用时s | 官方TO | 本地% | 判定 |
|---:|---|---|---:|---:|---|---:|---:|---:|---|
| 1 | `pb_csv_finance_report` | csv_analysis | **0.000** | — | 0/0 | 240 ⏱ | 180 | 0% | 未产出交付物 |
| 2 | `pb_csv_gdp_regions` | csv_analysis | **0.000** | 0.00 | 0/8 | 242 ⏱ | 180 | 0% | 未产出交付物 |
| 3 | `pb_csv_iris_summary` | csv_analysis | **0.000** | 0.00 | 0/7 | 241 ⏱ | 180 | 100% | 产出串题（写的是别题的交付物） |
| 4 | `pb_csv_life_exp_ranking` | csv_analysis | **0.000** | 0.00 | 0/9 | 241 ⏱ | 180 | 75% | 产出串题（写的是别题的交付物） |
| 5 | `pb_csv_stations_filter` | csv_analysis | **0.000** | 0.00 | 0/7 | 241 ⏱ | 180 | 88% | 产出串题（写的是别题的交付物） |
| 6 | `pb_csv_temp_anomalies` | csv_analysis | **0.000** | 0.00 | 0/9 | 241 ⏱ | 180 | 100% | 产出串题（写的是别题的交付物） |
| 7 | `pb_csv_temp_decades` | csv_analysis | **0.000** | 0.00 | 0/9 | 241 ⏱ | 180 | 100% | 产出串题（写的是别题的交付物） |
| 8 | `pb_csv_temp_trend` | csv_analysis | **0.000** | 0.00 | 0/9 | 241 ⏱ | 180 | 100% | 未产出交付物 |
| 9 | `pb_cve_security_triage` | analysis | **0.000** | 0.00 | 0/11 | 240 | 300 | 100% | 未产出交付物 |
| 10 | `pb_dockerfile_optimization` | coding | **0.000** | 0.00 | 0/8 | 241 ⏱ | 120 | 64% | 未产出交付物 |
| 11 | `pb_email_reply_drafting` | writing | **0.000** | — | 0/0 | 241 ⏱ | 240 | 100% | 未产出交付物 |
| 12 | `pb_financial_ratio_calculation` | analysis | **0.000** | 0.00 | 0/5 | 241 ⏱ | 240 | 100% | 未产出交付物 |
| 13 | `pb_log_apache_client_issues` | log_analysis | **0.000** | 0.00 | 0/5 | 241 ⏱ | 180 | 100% | 产出串题（写的是别题的交付物） |
| 14 | `pb_log_apache_critical` | log_analysis | **0.000** | — | 0/0 | 241 ⏱ | 180 | 69% | 产出串题（写的是别题的交付物） |
| 15 | `pb_log_apache_error_summary` | log_analysis | **0.000** | 0.00 | 0/5 | 241 ⏱ | 180 | 59% | 产出串题（写的是别题的交付物） |
| 16 | `pb_log_apache_timeline` | log_analysis | **0.000** | — | 0/0 | 241 ⏱ | 180 | 64% | 产出串题（写的是别题的交付物） |
| 17 | `pb_log_apache_top_errors` | log_analysis | **0.000** | — | 0/0 | 241 ⏱ | 180 | 85% | 产出串题（写的是别题的交付物） |
| 18 | `pb_log_hdfs_connections` | log_analysis | **0.000** | 0.00 | 0/5 | 241 ⏱ | 180 | 35% | 产出串题（写的是别题的交付物） |
| 19 | `pb_log_mapreduce_timeline` | log_analysis | **0.000** | 0.00 | 0/5 | 241 ⏱ | 180 | 9% | 未产出交付物 |
| 20 | `pb_log_nginx_errors` | log_analysis | **0.000** | 0.00 | 0/5 | 241 ⏱ | 180 | 24% | 产出串题（写的是别题的交付物） |
| 21 | `pb_log_nginx_slow_requests` | log_analysis | **0.000** | 0.00 | 0/5 | 241 ⏱ | 180 | 50% | 产出串题（写的是别题的交付物） |
| 22 | `pb_log_nginx_status_codes` | log_analysis | **0.000** | 0.00 | 0/5 | 241 ⏱ | 180 | 100% | 产出串题（写的是别题的交付物） |
| 23 | `pb_log_nginx_user_agents` | log_analysis | **0.000** | 0.00 | 0/5 | 241 ⏱ | 180 | 100% | 产出串题（写的是别题的交付物） |
| 24 | `pb_log_ssh_brute_force` | log_analysis | **0.000** | — | 0/0 | 241 ⏱ | 180 | 100% | 产出串题（写的是别题的交付物） |
| 25 | `pb_log_ssh_failed_logins` | log_analysis | **0.000** | 0.00 | 0/5 | 241 ⏱ | 180 | 100% | 未产出交付物 |
| 26 | `pb_log_ssh_successful` | log_analysis | **0.000** | 0.00 | 0/5 | 241 ⏱ | 180 | 100% | 未产出交付物 |
| 27 | `pb_log_ssh_unusual_times` | log_analysis | **0.000** | 0.00 | 0/5 | 241 ⏱ | 180 | 100% | 未产出交付物 |
| 28 | `pb_log_syslog_anomalies` | log_analysis | **0.000** | 0.00 | 0/5 | 241 ⏱ | 180 | 100% | 未产出交付物 |
| 29 | `pb_log_syslog_auth_failures` | log_analysis | **0.000** | 0.00 | 0/5 | 241 ⏱ | 180 | 71% | 产出串题（写的是别题的交付物） |
| 30 | `pb_log_syslog_cron` | log_analysis | **0.000** | 0.00 | 0/5 | 241 ⏱ | 180 | 100% | 产出串题（写的是别题的交付物） |
| 31 | `pb_log_syslog_services` | log_analysis | **0.000** | 0.00 | 0/5 | 241 ⏱ | 180 | 100% | 未产出交付物 |
| 32 | `pb_meeting_blog_post` | meeting_analysis | **0.000** | 0.00 | 0/8 | 241 ⏱ | 180 | 100% | 未产出交付物 |
| 33 | `pb_meeting_council_budget` | meeting_analysis | **0.000** | 0.00 | 0/10 | 241 ⏱ | 180 | 23% | 未产出交付物 |
| 34 | `pb_meeting_council_contact_info` | meeting_analysis | **0.000** | 0.00 | 0/10 | 241 ⏱ | 180 | 29% | 产出串题（写的是别题的交付物） |
| 35 | `pb_meeting_council_neighborhood` | meeting_analysis | **0.000** | 0.00 | 0/11 | 241 ⏱ | 180 | 28% | 未产出交付物 |
| 36 | `pb_meeting_council_votes` | meeting_analysis | **0.000** | 0.00 | 0/10 | 199 ⏱ | 180 | 16% | 未产出交付物 |
| 37 | `pb_meeting_executive_summary` | meeting_analysis | **0.000** | 0.00 | 0/8 | 241 ⏱ | 180 | 75% | 产出串题（写的是别题的交付物） |
| 38 | `pb_meeting_gov_next_steps` | meeting_analysis | **0.000** | 0.00 | 0/10 | 240 ⏱ | 180 | 16% | 未产出交付物 |
| 39 | `pb_meeting_searchable_index` | meeting_analysis | **0.000** | 0.00 | 0/8 | 241 ⏱ | 180 | 56% | 产出串题（写的是别题的交付物） |
| 40 | `pb_meeting_tech_messaging` | meeting_analysis | **0.000** | 0.00 | 0/9 | 241 ⏱ | 180 | 100% | 未产出交付物 |
| 41 | `pb_memory` | memory | **0.000** | 0.00 | 0/5 | 241 ⏱ | 120 | 63% | 产出串题（写的是别题的交付物） |
| 42 | `pb_pdf_to_calendar` | productivity | **0.000** | 0.00 | 0/8 | 241 ⏱ | 180 | 100% | 未产出交付物 |
| 43 | `pb_shell_command_generator` | coding | **0.000** | 0.00 | 0/5 | 241 ⏱ | 90 | 80% | 未产出交付物 |
| 44 | `pb_stock` | research | **0.000** | 0.00 | 0/6 | 241 ⏱ | 180 | 100% | 产出串题（写的是别题的交付物） |
| 45 | `pb_subway_navigation` | productivity | **0.000** | 0.00 | 0/1 | 241 ⏱ | 180 | 91% | 未产出交付物 |
| 46 | `pb_summary` | analysis | **0.000** | 0.00 | 0/1 | 241 ⏱ | 240 | 100% | 未产出交付物 |
| 47 | `pb_todo_list_cleanup` | productivity | **0.000** | 0.00 | 0/1 | 241 ⏱ | 120 | 100% | 未产出交付物 |
| 48 | `pb_meeting_gov_controversy` | meeting_analysis | **0.111** | 0.11 | 1/9 | 241 ⏱ | 180 | 54% | 部分 rubric 未命中 |
| 49 | `pb_csv_iris_classify` | csv_analysis | **0.625** | 0.62 | 5/8 | 241 ⏱ | 180 | 75% | 部分 rubric 未命中 |
| 50 | `pb_csv_cities_filter` | csv_analysis | **0.667** | 0.67 | 4/6 | 59 | 180 | 0% | 部分 rubric 未命中 |
| 51 | `pb_csv_gdp_ranking` | csv_analysis | **0.750** | 0.75 | 6/8 | 70 | 180 | 0% | 部分 rubric 未命中 |
| 52 | `pb_meeting_tech_action_items` | meeting_analysis | **0.778** | 0.78 | 7/9 | 97 | 180 | 47% | 部分 rubric 未命中 |
| 53 | `pb_csv_pension_risk` | csv_analysis | **0.800** | 0.80 | 8/10 | 150 | 180 | 15% | 部分 rubric 未命中 |
| 54 | `pb_log_hdfs_slow_ops` | log_analysis | **0.800** | 0.80 | 4/5 | 178 | 180 | 20% | 部分 rubric 未命中 |
| 55 | `pb_log_mapreduce_jobs` | log_analysis | **0.800** | 0.80 | 4/5 | 42 | 180 | 7% | 部分 rubric 未命中 |
| 56 | `pb_email_triage` | productivity | **0.818** | 0.82 | 9/11 | 32 | 240 | 0% | 部分 rubric 未命中 |
| 57 | `pb_calendar` | productivity | **0.833** | 0.83 | 5/6 | 18 | 120 | 100% | 部分 rubric 未命中 |
| 58 | `pb_csv_cities_density` | csv_analysis | **0.857** | 0.86 | 6/7 | 52 | 180 | 0% | 部分 rubric 未命中 |
| 59 | `pb_csv_cities_ranking` | csv_analysis | **0.875** | 0.88 | 7/8 | 42 | 180 | 0% | 部分 rubric 未命中 |
| 60 | `pb_csv_gdp_per_capita` | csv_analysis | **0.875** | 0.88 | 7/8 | 79 | 180 | 6% | 部分 rubric 未命中 |
| 61 | `pb_meeting_sentiment_analysis` | meeting_analysis | **0.875** | 0.88 | 7/8 | 59 | 180 | 31% | 部分 rubric 未命中 |
| 62 | `pb_meeting_tldr` | meeting_analysis | **0.875** | 0.88 | 7/8 | 41 | 180 | 16% | 部分 rubric 未命中 |
| 63 | `pb_csv_life_exp_change` | csv_analysis | **0.889** | 0.89 | 8/9 | 101 | 180 | 25% | 部分 rubric 未命中 |
| 64 | `pb_csv_pension_ranking` | csv_analysis | **0.889** | 0.89 | 8/9 | 75 | 180 | 31% | 部分 rubric 未命中 |
| 65 | `pb_meeting_advisory_acronyms` | meeting_analysis | **0.889** | 0.89 | 8/9 | 36 | 180 | 0% | 部分 rubric 未命中 |
| 66 | `pb_meeting_advisory_attendees` | meeting_analysis | **0.889** | 0.89 | 8/9 | 8 | 180 | 0% | 疑似判到残留旧文件 |
| 67 | `pb_meeting_gov_speaker_summary` | meeting_analysis | **0.889** | 0.89 | 8/9 | 67 | 180 | 38% | 部分 rubric 未命中 |
| 68 | `pb_meeting_tech_decisions` | meeting_analysis | **0.889** | 0.89 | 8/9 | 117 | 180 | 37% | 部分 rubric 未命中 |
| 69 | `pb_cron_organizer` | productivity | **0.900** | 0.90 | 9/10 | 42 | 120 | 100% | 部分 rubric 未命中 |
| 70 | `pb_test_generation` | coding | **0.917** | 0.92 | 11/12 | 91 | 180 | 53% | 部分 rubric 未命中 |
| 71 | `pb_csv_cities_growth` | csv_analysis | **1.000** | 1.00 | 6/6 | 239 ⏱ | 180 | 5% | 全部通过 |
| 72 | `pb_csv_iris_outliers` | csv_analysis | **1.000** | 1.00 | 7/7 | 156 | 180 | 20% | 全部通过 |
| 73 | `pb_csv_life_exp_outliers` | csv_analysis | **1.000** | 1.00 | 9/9 | 99 | 180 | 43% | 全部通过 |
| 74 | `pb_csv_pension_liability` | csv_analysis | **1.000** | 1.00 | 9/9 | 87 | 180 | 19% | 全部通过 |
| 75 | `pb_csv_stations_by_elevation` | csv_analysis | **1.000** | 1.00 | 7/7 | 47 | 180 | 0% | 全部通过 |
| 76 | `pb_csv_stations_coverage` | csv_analysis | **1.000** | 1.00 | 7/7 | 241 ⏱ | 180 | 15% | 全部通过 |
| 77 | `pb_csv_stock_best_worst` | csv_analysis | **1.000** | 1.00 | 9/9 | 128 | 180 | 25% | 全部通过 |
| 78 | `pb_csv_stock_trend` | csv_analysis | **1.000** | 1.00 | 9/9 | 119 | 180 | 21% | 全部通过 |
| 79 | `pb_csv_stock_volatility` | csv_analysis | **1.000** | 1.00 | 8/8 | 67 | 180 | 18% | 全部通过 |
| 80 | `pb_earnings_analysis` | analysis | **1.000** | 1.00 | 5/5 | 144 | 240 | 54% | 全部通过 |
| 81 | `pb_email_search` | analysis | **1.000** | 1.00 | 10/10 | 67 | 240 | 0% | 全部通过 |
| 82 | `pb_executive_lookup` | research | **1.000** | 1.00 | 5/5 | 14 | 180 | 0% | 全部通过 |
| 83 | `pb_k8s_debugging` | coding | **1.000** | 1.00 | 6/6 | 18 | 120 | 22% | 全部通过 |
| 84 | `pb_log_hdfs_block_ops` | log_analysis | **1.000** | 1.00 | 5/5 | 240 ⏱ | 180 | 20% | 全部通过 |
| 85 | `pb_log_hdfs_failures` | log_analysis | **1.000** | 1.00 | 5/5 | 99 | 180 | 25% | 全部通过 |
| 86 | `pb_log_hdfs_storage` | log_analysis | **1.000** | 1.00 | 5/5 | 87 | 180 | 4% | 全部通过 |
| 87 | `pb_log_mapreduce_failures` | log_analysis | **1.000** | 1.00 | 5/5 | 176 | 180 | 27% | 全部通过 |
| 88 | `pb_log_mapreduce_resources` | log_analysis | **1.000** | 1.00 | 5/5 | 180 ⏱ | 180 | 18% | 全部通过 |
| 89 | `pb_log_mapreduce_slow_tasks` | log_analysis | **1.000** | 1.00 | 5/5 | 111 | 180 | 20% | 全部通过 |
| 90 | `pb_log_nginx_traffic` | log_analysis | **1.000** | 1.00 | 5/5 | 99 | 180 | 41% | 全部通过 |
| 91 | `pb_log_ssh_user_activity` | log_analysis | **1.000** | 1.00 | 5/5 | 99 | 180 | 6% | 全部通过 |
| 92 | `pb_log_syslog_boot` | log_analysis | **1.000** | 1.00 | 10/10 | 121 | 180 | 26% | 全部通过 |
| 93 | `pb_meeting_advisory_stakeholders` | meeting_analysis | **1.000** | 1.00 | 9/9 | 126 | 180 | 47% | 全部通过 |
| 94 | `pb_meeting_advisory_technical` | meeting_analysis | **1.000** | 1.00 | 9/9 | 144 | 180 | 53% | 全部通过 |
| 95 | `pb_meeting_advisory_timeline` | meeting_analysis | **1.000** | 1.00 | 9/9 | 121 | 180 | 20% | 全部通过 |
| 96 | `pb_meeting_council_public_comment` | meeting_analysis | **1.000** | 1.00 | 9/9 | 178 | 180 | 31% | 全部通过 |
| 97 | `pb_meeting_council_upcoming` | meeting_analysis | **1.000** | 1.00 | 10/10 | 132 | 180 | 23% | 全部通过 |
| 98 | `pb_meeting_follow_up_email` | meeting_analysis | **1.000** | 1.00 | 9/9 | 38 | 180 | 33% | 全部通过 |
| 99 | `pb_meeting_gov_data_sources` | meeting_analysis | **1.000** | 1.00 | 10/10 | 204 ⏱ | 180 | 33% | 全部通过 |
| 100 | `pb_meeting_gov_qa_extract` | meeting_analysis | **1.000** | 1.00 | 9/9 | 227 ⏱ | 180 | 26% | 全部通过 |
| 101 | `pb_meeting_gov_recommendations` | meeting_analysis | **1.000** | 1.00 | 10/10 | 101 | 180 | 17% | 全部通过 |
| 102 | `pb_meeting_tech_competitors` | meeting_analysis | **1.000** | 1.00 | 9/9 | 85 | 180 | 43% | 全部通过 |
| 103 | `pb_meeting_tech_product_features` | meeting_analysis | **1.000** | 1.00 | 10/10 | 71 | 180 | 20% | 全部通过 |
| 104 | `pb_multi_file_refactoring` | coding | **1.000** | 1.00 | 15/15 | 18 | 120 | 25% | 全部通过 |
| 105 | `pb_spreadsheet_summary` | analysis | **1.000** | 1.00 | 9/9 | 44 | 180 | 27% | 全部通过 |
| 106 | `pb_access_log_anomaly` | analysis | **—** | — | 0/0 | 75 | 90 | 8% | 无自动检查，待人工/LLM 判 |
| 107 | `pb_blog` | writing | **—** | — | 0/0 | 71 | 300 | 100% | 无自动检查，待人工/LLM 判 |
| 108 | `pb_commit_message_writer` | writing | **—** | — | 0/0 | 24 | 120 | 100% | 无自动检查，待人工/LLM 判 |
| 109 | `pb_competitive_research` | research | **—** | — | 0/0 | 180 | 300 | 0% | 无自动检查，待人工/LLM 判 |
| 110 | `pb_contract_analysis` | analysis | **—** | — | 0/0 | 65 | 300 | 0% | 无自动检查，待人工/LLM 判 |
| 111 | `pb_daily_summary` | productivity | **—** | — | 0/0 | 89 | 300 | 20% | 无自动检查，待人工/LLM 判 |
| 112 | `pb_eli5_pdf_summary` | analysis | **—** | — | 0/0 | 99 | 300 | 11% | 无自动检查，待人工/LLM 判 |
| 113 | `pb_email` | writing | **—** | — | 0/0 | 241 ⏱ | 180 | 100% | 无自动检查，待人工/LLM 判 |
| 114 | `pb_events` | research | **—** | — | 0/0 | 30 | 300 | 12% | 无自动检查，待人工/LLM 判 |
| 115 | `pb_pricing_research` | research | **—** | — | 0/0 | 109 | 300 | 26% | 无自动检查，待人工/LLM 判 |
| 116 | `pb_readme_generation` | writing | **—** | — | 0/0 | 41 | 180 | 22% | 无自动检查，待人工/LLM 判 |

## 待补的 11 题

这些题 `grading_type` 是 `llm_judge`/无自动检查，且交付文件已写出，但本次只同步了文件名/大小/md5，**没有正文**，因此无法判内容正确性。补齐这些题需要把 B 上 `--save-raw` 的产物目录拉回来。

- `pb_access_log_anomaly` — 已产出 anomaly_report.json（completeness=1.0，correctness 未知）
- `pb_blog` — 已产出 blog_post.md（completeness=1.0，correctness 未知）
- `pb_commit_message_writer` — 已产出 commit_message.txt（completeness=1.0，correctness 未知）
- `pb_competitive_research` — 已产出 competitive_analysis.md（completeness=1.0，correctness 未知）
- `pb_contract_analysis` — 已产出 contract_analysis.md（completeness=1.0，correctness 未知）
- `pb_daily_summary` — 已产出 daily_briefing.md（completeness=1.0，correctness 未知）
- `pb_eli5_pdf_summary` — 已产出 eli5_summary.txt（completeness=1.0，correctness 未知）
- `pb_email` — 已产出 email_draft.txt（completeness=1.0，correctness 未知）
- `pb_events` — 已产出 events.md（completeness=1.0，correctness 未知）
- `pb_pricing_research` — 已产出 pricing_comparison.md（completeness=1.0，correctness 未知）
- `pb_readme_generation` — 已产出 readme.md（completeness=1.0，correctness 未知）

## 方法与已知局限

1. B 机的自动检查器是**逐条对 rubric** 的（已抽查 pension_risk / iris_classify / meeting_tldr，检查项与 rubric 行 1:1 对应），不是 v4d 那个恒等于 1.0 的伪字段，因此在有产出的题上直接采信。
2. 未产出交付物一律判 0：每题 rubric 第一行都是「文件 X 被创建」，文件不存在则整条 rubric 链失败。
3. **23 题存在串题污染**：本题窗口内落盘的是别题的交付物。把每个落盘文件按文件名归属回它所属的题、再和运行顺序对齐，可以看到交付物滞后 +1 到 +78 个任务位（228 个落盘文件中 69 个落在本题窗口、53 个落在更靠后的题、其余为中间脚本），说明超时后 SuperClaw 会话仍在后台继续写，产物落进了后面题目的工作区。这些题按 0 计，但成因是超时/串扰而非模型答错。
4. `pb_meeting_advisory_attendees` 反向可疑：8.1s / 400 output tokens、无新文件，却通过 8/9 检查，几乎可以肯定是判到了工作区里的残留文件，已标记为 low confidence。
5. 本地模型是 **qwen3.5-4b（硬件降级档）**，非官方 Qwen3-Coder-Next；云端是 MiniMax-M3 而非 GLM-5。绝对分不可与官方 ±0.03 容差直接对比。